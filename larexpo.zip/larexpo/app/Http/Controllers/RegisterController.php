<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;


class RegisterController extends Controller{

    public function view(){
        return view('register')
            ->with('csrf_token',csrf_token());
    }


    protected function create(){
        
        $request=request();
        $errors=$this->countErrors($request);
        if(count($errors) === 0){

            $newpsw = Hash::make($request['password'], ['rounds' => 12]);

            $newUser = User::create([
                'username'=> $request['username'],
                'email'=> $request['email'],
                'password'=> $newpsw,
                'name'=> $request['name'],
                'surname'=> $request['surname']
            ]);

            if($newUser !== null){

                Session::put("id", $user->id);
                return redirect('reservedArea');
            }

        }else{
            
            return redirect('register')->with('errors',$errors); //non sono riuscito a creare nuovo utente
        }

        
    }

    private function countErrors($dati){

        $error = array();

        //username 
        if(strlen($dati['username']) > 8)
            $error[]="Caratteri massimi username 8";
        else{
        $username = User::where('Username',$dati['username'])->first();
        if($username !== null)
            $error[]="Username già in uso";
        }
        //password
        if(strlen($dati['password']) < 8)
            $error[]="Caratteri password insufficienti";

        //conferma password
        if(strcmp($dati['password'],$dati['confirm_password']) != 0)
            $error[]="Le password non coincidono";

        return $error;
    }


}


?>