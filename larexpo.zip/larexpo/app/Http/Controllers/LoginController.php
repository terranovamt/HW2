<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;


class LoginController extends Controller{

    public function login(){

        //verifico se devo fare accesso
        if(session('user_id') != null){
            return redirect("reservedArea");
        }
        else{
            return view('login') 
                ->with('csrf_token',csrf_token());
        }
    }

    public function checkLogin(){

        $request=request();
        $errors=$this->countError($request);

        if(count($errors) == 0){

        $user = User::where('username',$request['username'])->first();
        //credenziali valide 
        Session::put("id", $user->id);
        
        return redirect('reservedArea');
        }
        else{
        //non ho trovato user
            return redirect('login')
                ->with('errors',$errors);

        }

    }


    private function countError($data){

        $error = array();

        $utente = User::where('username',$data['username'])->first();
        if($utente === null)
            $error[]="Username non corretto";
        
        else{
        $password = $utente->password;
        if (!(Hash::check($data['password'], $password)))
            $error[]='Password non corretta';

        }
        return $error;
    }


    public function logout(){
        Session::flush();
        return redirect('login');

    }

}


?>