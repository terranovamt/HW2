<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\User;

class ReservedAreaController extends Controller {

    public function view(){
        // Leggiamo l'utente connesso
        $user = User::find(session('id'));

        return view('reservedArea')
        ->with('username', $user->username);
        
        
    }
}
?>