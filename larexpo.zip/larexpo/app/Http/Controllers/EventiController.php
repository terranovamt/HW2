<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Evento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;



class EventiController extends Controller{

    public function view(){
          
        return view('eventi');
    } 

    public function carica(){
        $evento = Evento::all();
        return $evento;
    }

}


?>