<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;


class SpaziController extends Controller{

    public function view(){
          
        return view('spazi');
    } 
}


?>