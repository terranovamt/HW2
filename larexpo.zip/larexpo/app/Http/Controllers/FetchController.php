<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Evento;
use App\Models\User;
use App\Models\Modello;
use App\Models\Stand;
use App\Models\Standesterno;
use App\Models\Standinterno;
use App\Models\Esternoliberi;
use App\Models\Partecipa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;



class FetchController extends Controller{
    public function caricaspazi(){
        $stand = Modello::all();
        return $stand;
    }
    public function caricaeventi(){
        $evento = Evento::all();
        return $evento;
    }
    
    public function reportprenotati(){

        $user = User::find(session('id'));
        $userid = $user->id;
        $partecipa = Partecipa::where('azienda',$userid)->get()->toArray();
        $numevent = count($partecipa);
        $standinterno=array();
        $standesterno=array();
        $stands=array();
        $eventi=array();
        //print_r("numevent ".$numevent);
        //echo("<br><br><br>");
        for($i=0; $i < $numevent; $i++){
            $evento = $partecipa[$i]['evento'];
            $stand = $partecipa[$i]['stand'];
            

            //print_r("idevento ".$evento);
            //echo("<br><br><br>");
            $eventi[$i] = Evento::where('id',$evento)->first()->toArray();
            $stands[$i] = Stand::where('codice',$stand)->first()->toArray();
                $tipo = $stands[$i]["tipo"];
                if($tipo == 0){
                //esterno
                $standesterno[$i] = Standesterno::where('codice',$stands[$i]['codice'])->first()->toArray();
                }else{
                    //interno
                  $standinterno[$i] = Standinterno::where('codice',$stands[$i]['codice'])->first()->toArray();
                    //echo("<br><br><br>");
                    //print_r($standinterno);
                }
            
        }

        $array=array();

        if ($partecipa != NULL) {
            $array['partecipa']=$partecipa;
        }
        else{$array['partecipa']=0;}
        if ($stands != NULL) {
            $array['stand']=$stands;
        }
        else{$array['stand']=0;}
         if ($eventi != NULL){
            $array['evento']=$eventi;
        }else{$array['evento']=0;}
         if ($standesterno != NULL){
            $array['standesterno']=$standesterno;
        }else{$array['standesterno']=0;}
         if ($standinterno != NULL){
            $array['standinterno']=$standinterno;
        }else{$array['standinterno']=0;}
        return $array;
        
    }
    public function reporteventi(){

        $modello=array();
        $standinterno=array();
        $eventi=array();
        

        $user = User::find(session('id'));
        $userid = $user->id;
        $partecipa = Partecipa::where('azienda',$userid)->get()->toArray();
        $modello = Modello::all(); 
        $numevent = count($partecipa);
            $eventi = Evento::all();
           
        $array=array();

        if ($numevent != 0) {
            $array['partecipa']=$partecipa;
        }
        else{$array['partecipa']=array();}
         if ($eventi != NULL){
            $array['evento']=$eventi;
        }else{$array['evento']=array();}
         if ($modello != NULL){
            $array['modello']=$modello;
        }else{$array['modello']=array();}
        return $array;
        
    }

    public function prenotaaperto($evento){
        $liberi = Standesterno::where('disponibilita',0)->get('codice')->first()->toArray();
        $liberid =$liberi['codice'];
        $newprenotazioe = Partecipa::create([
            'evento'=>$evento,
            'azienda'=>session("id"),
            'stand'=> $liberid
        ]);
    }
    public function prenotachiuso($evento,$modello){

        $liberi = Standinterno::where('disponibilita',0)->where('modello',$modello)->get('codice')->first()->toArray();
        $liberid =$liberi['codice'];
        $newprenotazioe = Partecipa::create([
            'evento'=>$evento,
            'azienda'=>session("id"),
            'stand'=> $liberid
        ]);
    }

    public function eliminaevento($evento,$stand){
        print_r($evento);
        print_r($stand);
        $user = User::find(session('id'));
        $userid = $user->id;
        $prova = DB::delete("DELETE FROM partecipa WHERE evento = '$evento' AND azienda = '$userid' AND stand = '$stand'");
        print_r($prova);
    }
}


?>