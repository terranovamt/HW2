<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model {

    protected $table = 'evento';
    public $timestamps = false;

    protected $fillable = [
        'nome', 
        'img', 
        'edizione',
        'durata',
        'prezzo',
        'data_inizio',
        'data_fine'
    
    ];


    
}

?>