<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prodotto extends Model {

    protected $table = 'prodotto';
    protected $primaryKey="codice"; 
    protected $autoIncrement=false;
    public $timestamps = false;
    protected $fillable = [
        'codice', 
        'nome', 
        'categoria' 
    ];  
    
    public function espone() {
        return $this->belongsToMany("App\Models\Espone", "prodotto");
    }
}

?>