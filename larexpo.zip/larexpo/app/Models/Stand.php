<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Stand extends Model {

    protected $table = 'stand';
    protected $primaryKey="codice"; 
    protected $autoIncrement=false;
    public $timestamps = false;
    protected $fillable = [
        'codice', 
        'tipo' // 1 interno 0 esterno
    ];  
    


    public function partecipa(){
        return $this->belongsToMany("App\Models\Partecipa", "stand");
    }
    public function standinterno() {
        return $this->hasOne("App\Models\Standinterno","codice");
    }
    public function standesterno() {
        return $this->hasOne("App\Models\Standesterno","codice");
    }
}

?>