<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Standesterno extends Model {

        protected $table = 'standesterno';
        protected $primaryKey="codice"; 
        protected $autoIncrement=false;
        public $timestamps = false;
        protected $fillable = [
            'codice', 
            'numero', 
            'dimensione', 
            'disponibilita', 
            'posizione'
        ];  
        
        
        public function stand() {
            return $this->hasOne("App\Models\Stand","codice");
        }
        public function zona() {
            return $this->hasOne("App\Models\Zona");
        }
    }   
?>