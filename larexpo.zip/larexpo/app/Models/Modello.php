<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Modello extends Model {

    protected $table = 'modello';
    protected $primaryKey="nome";
    protected $autoIncrement=false;
    protected $keyType='string';


    protected $fillable = [
        'nome', 
        'img', 
        'descrizione'
    ];

   
    public function standinterno() {
        return $this->hasOne("App\Models\Standinterno","modello");
    }

    
}

?>