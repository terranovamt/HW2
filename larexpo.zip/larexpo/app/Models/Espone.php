<?php

namespace App\Models;
    use Illuminate\Database\Eloquent\Model;

class Espone extends Model
{
    protected $table="espone";
    public $timestamps = false;
    protected $fillable = [
        'prodotto', 
        'azienda', 
        'sponsor'
    ];

    public function user() {
        return $this->belongsToMany("App\Models\User");
    }
    public function prodotto() {
        return $this->belongsToMany("App\Models\Prodotto", "codice");
    }
    public function sponsor() {
        return $this->belongsToMany("App\Models\Sponsor", "nome");
    }
}
    
?>