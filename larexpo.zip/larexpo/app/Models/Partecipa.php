<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Partecipa extends Model {

    protected $table = 'partecipa';
    public $timestamps = false;
    protected $fillable = [
        'evento', 
        'azienda', 
        'stand', 
        'costo'
    ];

   

    public function user() {
        return $this->belongsToMany("App\Models\User");
    }
    public function evento() {
        return $this->belongsToMany("App\Models\Evento");
    }
    public function stand() {
        return $this->belongsToMany("App\Models\Stand","codice");
    }
    
}

?>