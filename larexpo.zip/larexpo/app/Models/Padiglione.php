<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Padiglione extends Model {

    protected $table = 'padilgione';
    protected $primaryKey="nome";
    protected $autoIncrement=false;
    protected $keyType='string';


    protected $fillable = [
        'nome', 
        'dimensione'
    ];

   
    public function standinterno() {
        return $this->hasOne("App\Models\Standinterno","posizione");
    }

    
}

?>