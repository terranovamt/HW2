<?php

namespace App\Models;
    
use Illuminate\Database\Eloquent\Model;

class User extends Model
{


    protected $table="users";
    public $timestamps = false;
    protected $fillable = [
        'username', 
        'email', 
        'password',
        'name',
        'surname'
    ];

    public function partecipa() {
        return $this->belongsToMany("App\Models\Partecipa", "azienda");
    }
    public function espone() {
        return $this->belongsToMany("App\Models\Espone", "azienda");
    }
}
?>