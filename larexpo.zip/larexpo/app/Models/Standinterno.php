<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Standinterno extends Model {

        protected $table = 'standinterno';
        protected $primaryKey="codice"; 
        protected $autoIncrement=false;
        public $timestamps = false;
        protected $fillable = [
            'codice', 
            'numero', 
            'dimensione', 
            'disponibilita', 
            'posizione', 
            'modello'
        ];  
        
        
        public function stand() {
            return $this->hasOne("App\Models\Stand","codice");
        }
        public function modello() {
            return $this->hasOne("App\Models\Modello","nome");
        }
        public function padiglione() {
            return $this->hasOne("App\Models\Padiglione","nome");
        }
    }
?>