<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sponsor extends Model {

    protected $table = 'sponsor';
    protected $primaryKey="nome";
    protected $autoIncrement=false;
    protected $keyType='string';
    public $timestamps = false;

    protected $fillable = [
        'nome'
    ];

   
    public function espone() {
        return $this->hasOne("App\Models\Espone","sponsor");
    }

    
}

?>