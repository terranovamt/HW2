<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('home');
});


//index
Route::get('/home',"HomeController@view")->name('home');
Route::get('/spazi',"SpaziController@view")->name('spazi');
Route::get('/eventi',"EventiController@view")->name('eventi');
Route::get('/login',"LoginController@login")->name('login');
Route::get('/logout',"LoginController@logout")->name('logout');
Route::get('/register',"RegisterController@view")->name('register');
Route::get('/reservedArea', 'ReservedAreaController@view')->name('reservedArea');

//post form login e signup
Route::post('/login',"LoginController@checkLogin");
Route::post('/register',"RegisterController@create");









//fetch
Route::get('/fetch/caricaspazi',"FetchController@caricaspazi");
Route::get('/fetch/caricaeventi',"FetchController@caricaeventi");
Route::get('/fetch/reportprenotati',"FetchController@reportprenotati");
Route::get('/fetch/reporteventi',"FetchController@reporteventi");
Route::get('/fetch/prenotaaperto/{q1}',"FetchController@prenotaaperto");
Route::get('/fetch/eliminaevento/{q1}/{q2}',"FetchController@eliminaevento");
Route::get('/fetch/prenotachiuso/{q1}/{q2}',"FetchController@prenotachiuso");







?>