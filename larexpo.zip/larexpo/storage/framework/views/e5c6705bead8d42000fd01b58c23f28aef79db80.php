<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>work</title>
    <link rel="shortcut icon" href="../img/logo.ico" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&family=Syne+Mono&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link rel="stylesheet" href="<?php echo e(asset('style/work.css')); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>
  <body>
    <header>
      <div>
        <h1>QUESTA PAGINA NON E' DISPONIBILE</h1>
        <a class="button" href="<?php echo e(route('home')); ?>"> Torna alla Home</a>
      </div>
    </header>

    <footer>
      <div>
        <img src="./img/profilo.png" />
        <div id="contatto">
          <h1>Terranova Matteo</h1>
          <p>O46002133</p>
        </div>
      </div>
    </footer>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\larexpo\resources\views/work.blade.php ENDPATH**/ ?>