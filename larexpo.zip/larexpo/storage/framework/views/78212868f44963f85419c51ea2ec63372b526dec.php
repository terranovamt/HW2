<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EXPO</title>
    <link rel="shortcut icon" href="../img/logo.ico" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&family=Syne+Mono&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(url('style/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('style/riservata.css')); ?>" />
     <!------------------>
     <script src='<?php echo e(url("script/riservata.js")); ?>' defer ></script> 
    </head>

    <body>
        <form></form>
        <header>
        <nav id="menu">
        <a class="button" href="<?php echo e(route('home')); ?>">Home</a>
        <a class="button" href="<?php echo e(route('spazi')); ?>">Spazi</a>
        <a class="button" href="<?php echo e(route('eventi')); ?>">Eventi</a>
      </nav>
        <h1>
            <strong>Aziende </strong>     
        </h1>
        <div class="logout">
            <a class="button" href="<?php echo e(route('logout')); ?>">Logout</a>
        </div>
        </header>

        <span class ="nomeazienda"><h1>ECCOVI, <?php echo e($username); ?> !</h1></span>
        <main>
                      
            <section class="left">
                <nav class="sidebar"> 
                    <div class="active" id="home">
                        Home
                    </div>
                    <div id="resevent">
                        Prenotazione eventi
                        
                    </div>                  
                </nav>
                
                
          
            </section>
            <section class="right">
                <div id ="title"></div>
                <divid id="content"></div>
                
            </section>
            
        </main>

        <footer>
            <div>
            <div id="img"></div>
            <div id="contatto">
                <h1>Terranova Matteo</h1>
                <p>O46002133</p>
            </div>
            </div>
        </footer>
    </body>
</html><?php /**PATH C:\xampp\htdocs\larexpo\resources\views/reservedArea.blade.php ENDPATH**/ ?>