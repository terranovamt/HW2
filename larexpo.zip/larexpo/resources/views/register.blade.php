 <html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EXPO</title>
    <link rel="shortcut icon" href="../img/logo.ico" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&family=Syne+Mono&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('style/style.css')}}" />
    <link rel="stylesheet" href="{{asset('style/signup.css')}}" />
    <script src="{{asset('script/signup.js')}}" defer></script>
    </head>
    <body>
    <header>
    <nav id="menu">
        <a class="button" href="{{route('home')}}">Home</a>
        <a class="button" href="{{route('spazi')}}">Spazi</a>
        <a class="button" href="{{route('eventi')}}">Eventi</a>
      </nav>
    <h1>
      <strong>Aziende</strong>
    </h1>
  </header>
        <main>
        <section>
                    <h1>Presentati</h1>
            <form id='signup' method='post' >
            
            <input type='hidden' name = '_token' value='{{ $csrf_token }}'>
            <span>
            @if( $errors != "[]")
                
                @foreach($errors as $error)
                <div class='error'>{{$error}}</div>
                @endforeach 
            
            @endif
            </span>
                <div class="row">
                    <div class="name">
                        <div><label for='name'>Nome</label></div>
                        <!-- Se il submit non va a buon fine, il server reindirizza su questa stessa pagina, quindi va ricaricata con 
                            i valori precedentemente inseriti -->
                        <div><input type='text' name='name'  ></div>
                        <span></span>
                    </div>
                    <div class="surname">
                        <div><label for='surname'>Cognome</label></div>
                        <div><input type='text' name='surname'  ></div>
                        <span></span>
                    </div>
                </div>
                <div class="row">

                    <div class="username">
                        <div><label for='username'>Nome azienda</label></div>
                        <div><input type='text' name='username' ></div>
                        <span>Nome utente non disponibile</span>
                    </div>
                    <div class="email">
                        <div><label for='email'>Email</label></div>
                        <div><input type='text' name='email' ></div>
                        <span>Indirizzo email non valido</span>
                    </div>
                </div>
                <div class="row">
                    <div class="password">
                        <div><label for='password'>Password</label></div>
                        <div><input type='password' name='password'></div>
                        <span>Inserisci almeno 8 caratteri</span>
                    </div>
                    <div class="confirm_password">
                        <div><label for='confirm_password'>Conferma Password</label></div>
                        <div><input type='password' name='confirm_password' ></div>
                        <span>Le password non coincidono</span>
                    </div>
                </div>
                
                
                <div class="submit">
                    <input type='submit' value="Registrati" id="submit" >
                </div>
            </form>
        </section>
        
        </main>
        <footer>
    <div>
      <div id="img"></div>
      <div id="contatto">
        <h1>Terranova Matteo</h1>
        <p>O46002133</p>
      </div>
    </div>
  </footer>
    </body>
</html>