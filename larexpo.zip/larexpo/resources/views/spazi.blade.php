<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EXPO</title>
    <link rel="shortcut icon" href="./img/logo.ico" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&family=Syne+Mono&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('style/style.css')}}" />
    <!------------------>
    <link rel="stylesheet" href="{{asset('style/spazi.css')}}" />
    <script src="{{asset('script/spazi.js')}}" defer></script>
  </head>
</html>

<body>
  <header>
    <nav id="menu">
        <a class="button" href="{{ route('home') }}">Home</a>
        <a class="button" href="{{ route('spazi') }}">Spazi</a>
        <a class="button" href="{{ route('eventi') }}">Eventi</a>
    </nav>
    <h1>
      <strong>SPAZI </strong>
    </h1>
  </header>

  <main>
    <section class="hidden" id="preferiti">
      <h1>Preferiti:</h1>
      <div class="stand-grid"></div>
    </section>
    <section id="section-name">
      <h1>Stand :</h1>
      <input type="text" id="barra-ricerca" placeholder="Cerca" />
    </section>
    <section class="stand-grid" id="elenco"></section>
  </main>

  <footer>
    <div>
      <div id="img"></div>
      <div id="contatto">
        <h1>Terranova Matteo</h1>
        <p>O46002133</p>
      </div>
    </div>
  </footer>
</body>
