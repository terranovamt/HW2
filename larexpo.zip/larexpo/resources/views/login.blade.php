<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EXPO</title>
    <link rel="shortcut icon" href="./img/logo.ico" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&family=Syne+Mono&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('style/style.css')}}" />
    <!----------------------------------------------->
    <link rel="stylesheet" href="{{asset('style/accedi.css')}}" />
    <!----------------------------------------------->
    <script src='{{ url("script/login.js")}}' defer ></script> 
        
  </head>
  <body>
  <header>
  <nav id="menu">
        <a class="button" href="{{route('home')}}">Home</a>
        <a class="button" href="{{route('spazi')}}">Spazi</a>
        <a class="button" href="{{route('eventi')}}">Eventi</a>
      </nav>
    <h1>
      <strong>Aziende</strong>
    </h1>
  </header>
    <main>
    <section class="main_left">
      <div class="signup">La tua azienda non é iscritta?   <a href="{{ route('register') }}">Iscriviti</a>
        </section>
    <section class="main_right">
            <h1>Bentornati</h1>
            <form id='myForm' name='login' method='post'>
            @if( $errors != "[]")
                
                @foreach($errors as $error)
                <div class='error'>{{$error}}</div>
                @endforeach 
            
            @endif
            <input type='hidden' name = '_token' value='{{ $csrf_token }}'>
                <div class="username">
                    <div><label for='username'>Nome azienda</label></div>
                    <div><input type='text' name='username'@if(isset($oldLoginUsername)) value='{{$oldLoginUsername}}' @endif></div>
                </div>
                <div class="password">
                    <div><label for='password'>Password</label></div>
                    <div><input type='password' name='password' ></div>
                  <div class="remember">
                    <div><input type='checkbox' name='remember' value="1" ></div>
                    <div><label for='remember'>Ricorda l'accesso</label></div>
                </div>
                </div>
                    <div class="accedi">
                    <input type='submit' value="Accedi">
                </div>
            </form>
        </section>
    </main>
    <footer>
    <div>
      <div id="img"></div>
      <div id="contatto">
        <h1>Terranova Matteo</h1>
        <p>O46002133</p>
      </div>
    </div>
  </footer>
  </body>
</html>