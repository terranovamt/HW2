//validazione

function validazione(event){

    const formData = new FormData(document.querySelector("#myForm"));
    const username=formData.get('username');
    const password=formData.get('password');
     
    //verifico che non siano nulli
    if(username.length == 0 || password.lenght == 0){

        //errore
        event.preventDefault();
    }


}

const form = document.getElementById('myForm');
form.addEventListener("submit",validazione);