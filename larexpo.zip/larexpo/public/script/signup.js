//devo fare la validation dei campi del form
function validazione(event){


  const formData = new FormData(document.querySelector("#signup"));

  const nome=formData.get('name');
  const cognome=formData.get('surname');
  const username=formData.get('username');
  const password=formData.get('password');
  const conf_password=formData.get('confirm_password');
  

  
  

  //vedo se il form è stato riempito o meno
  if(nome.length == 0 || cognome.length == 0 || username.length == 0 || fiscale.length == 0 || password.length == 0 || conf_password.length == 0)
  { 
      console.log("Riempi i campi");
      event.preventDefault();

  }
  
  
  
}

const form = document.getElementById('signup');
form.addEventListener("submit",validazione);